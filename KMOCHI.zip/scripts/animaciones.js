document.addEventListener("DOMContentLoaded", () => {
  console.log("Animación de entrada activada.");
});